Gitbook Anchors Plugin
==============

Add Github style heading anchors to your book.

![](https://cloud.githubusercontent.com/assets/2666107/3465465/9fc9a502-0266-11e4-80ca-09a1dad1473e.png)

Install in your book using
	 
```
$ npm install --save gitbook-plugin-anchors
```

Add the plugin to your `book.json`:
    
```
{
	"plugins" : [ "anchors" ]
}		
```

