## Introducing PressRoom

![PressRoom](http://press-room.io/) Official Documentation.

> While we constatly put our efforts in keeping this documentation updated,  some some of its parts or media may not reflect the latest version of the software. 

> Contributions are welcome
> https://github.com/thePrintLabs/PressRoom-Docs 

> 
> Visit the PressRoom forum for any usage related questions or suggestion.
> http://discourse.press-room.io/ 

